@include('layouts.header')
@include('layouts.topbar')

<style>
    .thin-scrollbar::-webkit-scrollbar {
        width: 5px;
        height: 5px;
    }
    .thin-scrollbar::-webkit-scrollbar-track {
        background: #1A1A1A;
        border-radius: 10px;
    }
    .thin-scrollbar::-webkit-scrollbar-thumb {
        background: #4B5563;
        border-radius: 10px;
    }
    .thin-scrollbar::-webkit-scrollbar-thumb:hover {
        background: #6B7280;
    }
    .thin-scrollbar {
        scrollbar-width: thin;
        scrollbar-color: #4B5563 #1A1A1A;
    }
</style>

<div id="main-content" class="pt-20 pb-6 px-4 sm:px-6 max-w-8xl mx-auto w-full overflow-hidden flex flex-col h-[calc(100dvh)] max-h-[calc(100dvh)]">
    <div class="bg-surface-900 rounded-2xl shadow-xl border border-border-800 overflow-hidden flex-1 flex flex-col min-h-0">

        <!-- Header -->
        <div class="px-4 sm:px-6 py-3 sm:py-4 border-b border-border-800 bg-surface-800 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1">
            <h2 class="text-lg sm:text-xl font-semibold text-text-100 flex items-center gap-2">
                <span class="leading-tight uppercase">API Settings</span>
            </h2>
            <span class="text-xs sm:text-sm text-text-400">Generate and manage API keys</span>
        </div>

        <!-- Content -->
        <div class="flex-1 overflow-y-auto thin-scrollbar min-h-0 bg-background-900 py-5 px-5 sm:px-8 space-y-8">

            <!-- Add new key form -->
            <div class="bg-surface-800 rounded-xl border border-border-700 p-5 sm:p-6">
                <h3 class="text-sm font-semibold text-text-200 mb-4 uppercase tracking-wide">Generate New API Key</h3>
                <form id="apiKeyForm" class="space-y-4">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="ownerLabel" class="block text-sm font-medium text-text-300 mb-1.5">Owner Label</label>
                            <input type="text" id="ownerLabel" placeholder="Enter owner label" required
                                class="w-full px-4 py-2.5 border border-border-600 rounded-lg
                                       bg-surface-900 text-text-100 placeholder-text-500
                                       focus:ring-2 focus:ring-radar-500/50 focus:border-radar-500 text-sm transition">
                        </div>

                        <div>
                            <label for="tokenHash" class="block text-sm font-medium text-text-300 mb-1.5">Token Hash</label>
                            <div class="flex gap-2">
                                <input type="text" id="tokenHash" readonly
                                    class="flex-1 px-4 py-2.5 border border-border-600 rounded-lg
                                           bg-surface-900 text-text-300 text-sm font-mono
                                           focus:outline-none">
                                <button type="button" id="generateBtn"
                                    class="px-4 py-2.5 bg-radar-600 hover:bg-radar-500 text-text-100 text-sm font-medium rounded-lg transition border border-radar-500/40 shrink-0">
                                    Generate
                                </button>
                            </div>
                        </div>
                    </div>

                    <button type="submit" id="saveBtn"
                        class="w-full px-4 py-2 bg-munti-green-600 hover:bg-munti-green-500 text-text-100 font-semibold rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed border border-munti-green-500/30">
                        Save API Key
                    </button>
                </form>
                <div id="status" class="mt-3 text-sm font-medium text-center"></div>
            </div>

            <!-- Existing keys list -->
            @if($keys->isNotEmpty())
                <div>
                    <h3 class="text-sm font-semibold text-text-200 mb-3 uppercase tracking-wide">Active API Keys</h3>
                    <div class="bg-surface-800 rounded-xl border border-border-700 overflow-x-auto thin-scrollbar">
                        <table class="min-w-full divide-y divide-border-700">
                            <thead class="bg-surface-900/80 text-xs uppercase tracking-wider text-text-400">
                                <tr>
                                    <th scope="col" class="px-4 py-3 text-left font-medium">Owner Label</th>
                                    <th scope="col" class="px-4 py-3 text-left font-medium">Token Hash</th>
                                    <th scope="col" class="px-4 py-3 text-left font-medium">Status</th>
                                    <th scope="col" class="px-4 py-3 text-left font-medium">Created</th>
                                    <th scope="col" class="px-4 py-3 text-right font-medium">Action</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-border-800">
                                @foreach($keys as $key)
                                    <tr class="hover:bg-surface-700/60 transition">
                                        <td class="px-4 py-1 whitespace-nowrap font-mono text-sm text-text-100">
                                            {{ $key->owner_label }}
                                        </td>
                                        <td class="px-4 py-1 font-mono text-sm text-text-400 truncate max-w-xs">
                                            {{ $key->token_hash }}
                                        </td>
                                        <td class="px-4 py-1 whitespace-nowrap">
                                            <span class="px-2.5 py-0.5 rounded-full text-xs font-medium border
                                                {{ $key->enabled
                                                    ? 'bg-munti-green-700/20 text-munti-green-400 border-munti-green-600/30'
                                                    : 'bg-munti-red-700/20 text-munti-red-400 border-munti-red-600/30' }}">
                                                {{ $key->enabled ? 'Enabled' : 'Disabled' }}
                                            </span>
                                        </td>
                                        <td class="px-4 py-1 whitespace-nowrap text-xs text-text-500">
                                            {{ $key->created_at->format('Y-m-d H:i') }}
                                        </td>
                                        <td class="px-4 py-1 whitespace-nowrap text-right">
                                            <button type="button"
                                                class="delete-key text-munti-red-400 hover:text-munti-red-300 transition p-1 rounded hover:bg-munti-red-700/20"
                                                data-token="{{ $key->token_hash }}"
                                                title="Delete key">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="1.35em" height="1.35em" viewBox="0 0 24 24">
                                                    <path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>
                                                </svg>
                                            </button>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            @endif

        </div>
    </div>
</div>

<script>
    const ownerLabelInput = document.getElementById('ownerLabel');
    const tokenHashInput = document.getElementById('tokenHash');
    const generateBtn = document.getElementById('generateBtn');
    const saveBtn = document.getElementById('saveBtn');
    const status = document.getElementById('status');
    const form = document.getElementById('apiKeyForm');

    // ----- Helper: set status with color -----
    function setStatus(message, type = 'info') {
        status.className = 'mt-3 text-sm font-medium text-center';
        switch (type) {
            case 'success':
                status.classList.add('text-munti-green-400');
                break;
            case 'error':
                status.classList.add('text-munti-red-400');
                break;
            case 'info':
                status.classList.add('text-radar-400');
                break;
            case 'warning':
                status.classList.add('text-munti-yellow-400');
                break;
            default:
                status.classList.add('text-text-400');
        }
        status.textContent = message;
    }

    // ----- Generate a random key from server -----
    async function generateKey() {
        setStatus('Generating...', 'info');
        try {
            const response = await fetch('{{ route('api.keys.generate') }}', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                }
            });
            const data = await response.json();
            if (data.key) {
                tokenHashInput.value = data.key;
                setStatus('Key generated', 'success');
                validateForm();
            } else {
                setStatus('Failed to generate', 'error');
            }
        } catch (err) {
            setStatus('Server error', 'error');
            console.error(err);
        }
    }

    // ----- Validate that label and hash are filled -----
    function validateForm() {
        const label = ownerLabelInput.value.trim();
        const hash = tokenHashInput.value.trim();
        saveBtn.disabled = !(label && hash);
    }

    // ----- Auto-generate on page load -----
    window.addEventListener('DOMContentLoaded', () => {
        generateKey();
    });

    generateBtn.addEventListener('click', generateKey);
    ownerLabelInput.addEventListener('input', validateForm);

    // ----- Save the key -----
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const owner_label = ownerLabelInput.value.trim();
        const token_hash = tokenHashInput.value.trim();
        if (!owner_label || !token_hash) return;

        setStatus('Saving...', 'info');
        try {
            const response = await fetch('{{ route('api.keys.save') }}', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                },
                body: JSON.stringify({ owner_label, token_hash })
            });
            const data = await response.json();
            if (data.success) {
                setStatus('API key saved successfully!', 'success');
                ownerLabelInput.value = '';
                tokenHashInput.value = '';
                validateForm();
                setTimeout(() => location.reload(), 800);
            } else {
                setStatus('' + (data.error || 'Save failed'), 'error');
            }
        } catch (err) {
            setStatus('Server error', 'error');
            console.error(err);
        }
    });

    // ----- Delete key -----
    document.querySelectorAll('.delete-key').forEach(btn => {
        btn.addEventListener('click', async function() {
            const token = this.dataset.token;
            const row = this.closest('tr');
            const ownerLabel = row.querySelector('td:first-child')?.textContent.trim() || 'this key';
            if (!confirm(`Delete API key "${ownerLabel}"? This cannot be undone.`)) return;

            try {
                const response = await fetch(`/api-keys/${token}`, {
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                        'Content-Type': 'application/json'
                    }
                });
                const data = await response.json();
                if (data.success) {
                    row.remove();
                    const tbody = document.querySelector('tbody');
                    if (tbody && tbody.querySelectorAll('tr').length === 0) {
                        const container = tbody.closest('.mb-8') || tbody.closest('div');
                        if (container) container.remove();
                    }
                    setStatus('Key deleted successfully!', 'success');
                } else {
                    setStatus('Failed to delete key.', 'error');
                }
            } catch (err) {
                setStatus('Server error', 'error');
                console.error(err);
            }
        });
    });
</script>

@include('layouts.footer')